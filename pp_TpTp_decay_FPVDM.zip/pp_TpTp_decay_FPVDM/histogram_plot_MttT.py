import numpy as np
import matplotlib.pyplot as plt

from read_hist import read_histogram

values1, xc, dx= read_histogram("MttT_1500_100.tab")
values2, xc, dx= read_histogram("MttT_1500_500.tab")
values3, xc, dx= read_histogram("MttT_1500_900.tab")


# Plot using steps
plt.figure(figsize=(5, 3))   # <-- control figure size here
plt.plot(xc, values1, ls="-", drawstyle="steps-mid", label="$M_{T'}$=1.5 TeV, $M_V'=$100 GeV", color='b')
plt.plot(xc, values2, ls="-", drawstyle="steps-mid", label="$M_{T'}$=1.5 TeV, $M_V'=$500 GeV", color='r')
plt.plot(xc, values3, ls="-", drawstyle="steps-mid", label="$M_{T'}$=1.5 TeV, $M_V'=$900 GeV", color='g')

ymin = 1E-4       # <-- set what you want
ymax = 2*max(values2)  # <-- or a custom value, e.g. 0.1
plt.ylim(ymin, ymax)
plt.yscale("log")

plt.xlabel("$M_{ttt}$")
plt.ylabel("Normalised distribution")
#plt.title("Histogram from Tt.tab")

plt.legend()   # <-- REQUIRED
plt.tight_layout()

plt.savefig("plot_Mttt.pdf")
plt.close()
