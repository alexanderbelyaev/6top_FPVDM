import numpy as np
import matplotlib.pyplot as plt


from read_hist import read_histogram

values1, xc, dx= read_histogram("T_Tt_1500_100.tab")
values2, xc, dx= read_histogram("T_Tt_1500_500.tab")
values3, xc, dx= read_histogram("T_Tt_1500_900.tab")


# Plot using steps
plt.figure(figsize=(5, 3))   # <-- control figure size here
plt.plot(xc, values1, ls="-", drawstyle="steps-mid", label="$M_{T'}$=1.5 TeV, $M_V'=$100 GeV", color='b')
plt.plot(xc, values2, ls="-", drawstyle="steps-mid", label="$M_{T'}$=1.5 TeV, $M_V'=$500 GeV", color='r')
plt.plot(xc, values3, ls="-", drawstyle="steps-mid", label="$M_{T'}$=1.5 TeV, $M_V'=$900 GeV", color='g')

ymin = 1E-3       # <-- set what you want
ymax = 1.1*max(values2)  # <-- or a custom value, e.g. 0.1
plt.ylim(ymin, ymax)
#plt.yscale("log")

plt.xlabel("$P_T^{\\bar{t}t}$")
plt.ylabel("Normalised distribution")
#plt.title("Histogram from Tt.tab")

plt.legend(fontsize=8)   # <-- REQUIRED
plt.tight_layout()

plt.savefig("plot_T_Tt.pdf")
plt.close()
