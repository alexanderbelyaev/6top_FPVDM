import numpy as np

def read_histogram(fname):
    xmin = xmax = xdim = None
    data_lines = []

    with open(fname) as f:
        for line in f:
            if line.startswith("#"):
                if line.startswith("#xMin"):
                    xmin = float(line.split()[1])
                elif line.startswith("#xMax"):
                    xmax = float(line.split()[1])
                elif line.startswith("#xDim"):
                    xdim = int(line.split()[1])
            else:
                data_lines.append(line)

    data = np.loadtxt(data_lines)
    values = data[:, 0]

    binwidth = (xmax - xmin) / xdim
    total_area = (values * binwidth).sum()
    values_norm = values / total_area

    bins = np.linspace(xmin, xmax, xdim + 1)
    xcenters = 0.5 * (bins[:-1] + bins[1:])

    return values_norm, xcenters, binwidth
